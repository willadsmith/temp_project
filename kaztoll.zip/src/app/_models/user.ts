﻿export class User {
    user: object;
    token: object;
    role: string;
    // id: number;
    // username: string;
    // password: string;
    firstName: string;
    lastName: string;
    // token?: string;
}