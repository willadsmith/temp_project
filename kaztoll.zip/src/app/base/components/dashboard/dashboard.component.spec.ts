import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseDashboardComponent } from './dashboard.component';

// describe('DashboardComponent', () => {
//   let component: BaseDashboardComponent;
//   let fixture: ComponentFixture<BaseDashboardComponent>;
//
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ BaseDashboardComponent ]
//     })
//     .compileComponents();
//   }));
//
//   beforeEach(() => {
//     fixture = TestBed.createComponent(BaseDashboardComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });
//
//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
