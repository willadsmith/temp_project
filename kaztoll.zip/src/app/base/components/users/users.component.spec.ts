import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseUsersComponent } from './users.component';

// describe('UsersComponent', () => {
//   let component: BaseUsersComponent;
//   let fixture: ComponentFixture<BaseUsersComponent>;
//
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ BaseUsersComponent ]
//     })
//     .compileComponents();
//   }));
//
//   beforeEach(() => {
//     fixture = TestBed.createComponent(BaseUsersComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });
//
//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
