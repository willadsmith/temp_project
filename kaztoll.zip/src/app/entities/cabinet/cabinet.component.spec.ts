import {CabinetComponent} from './cabinet.component';

// describe('Component: Layout', () => {
//   it('should create an instance', () => {
//     const component = new CabinetComponent();
//     expect(component).toBeTruthy();
//   });
// });
