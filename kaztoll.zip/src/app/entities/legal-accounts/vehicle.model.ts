export interface Vehicle {
  licencePlate: string;
  isAdded: boolean;
  cardNumber: boolean;
}
